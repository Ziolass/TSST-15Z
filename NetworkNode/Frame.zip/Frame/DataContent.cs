﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkNode.Frame
{
    class DataContent : IContent
    {
        public ContentType Type { get; private set; }
        public String Content { get; private set; }

        public DataContent(string content)
        {
            Type = ContentType.CONTAINER;
            Content = content;
        } 
    }
}
