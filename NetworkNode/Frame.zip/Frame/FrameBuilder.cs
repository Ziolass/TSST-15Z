﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkNode.Frame
{
    public class FrameBuilder
    {
        private JObject metadata;

        public FrameBuilder(string textFrame)
        {
            metadata = JObject.Parse(textFrame);
        }

        public Frame BuildFrame(string textFrame)
        {
            Frame result = new Frame();

            result.Msoh = metadata["MSOH"].ToObject<string>();
            result.Rsoh = metadata["RSOH"].ToObject<string>();


            return null;
        }

        private IContent[] evaluateContents(JArray contents)
        {
            IContent[]
            foreach (JObject content in contents) {

            }
        }

        private IContent evaluateContent(JObject content)
        {
            string txtType = content["TYPE"].ToObject<string>();
            
            ContentType type = FrameEnumsExtensions.GetType(txtType);
            IContent payload;
            if (type == ContentType.CONTAINER)
            {
                payload
            }
            else
            {

            }
            
            return null;
        }

        

    }
}
