﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkNode.Frame
{
    public class Container : IContent
    {
        public ContentType Type { get; private set; }
        public ContainerLevel Level { get; private set; }

        public string Pointer { get; set; }
        public string Poh { get; set; }

        public IContent Content { get; private set; }

        public Container(ContainerLevel level)
        {
            Type = ContentType.CONTAINER;
            Level = level;
        }

        
        //TODO: tą logikę wyciągnąć do buildera
        public bool TryAddContent(IContent content)
        {
            if (content.Type == ContentType.DATA)
            {
                Content = content;
                return true;
            }

            Container container = (Container)content;

            if (this.Level < container.Level)
            {
                return false;
            }

            Content = content;
            return true;
        }

    } 
}
