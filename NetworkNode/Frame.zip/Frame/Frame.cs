﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NetworkNode.Frame
{
    public enum ContainerLevel { AU4, TUG3, TUG2, TUG12, UNDEF }
    public enum ContentType { CONTAINER, DATA, UNDEF }

    public static class FrameEnumsExtensions 
    {
        public static ContainerLevel GetLevel(string level)
        {
            switch (level)
            {
                case "AU4":
                    {
                        return ContainerLevel.AU4;
                    }
                case "TUG3":
                    {
                        return ContainerLevel.TUG3;
                    }
                case "TUG2":
                    {
                        return ContainerLevel.AU4;
                    }
                case "TUG12":
                    {
                        return ContainerLevel.TUG3;
                    }
                default:
                    {
                        return ContainerLevel.UNDEF;
                    }
            }
        }

        public static ContentType GetType(string type)
        {
            switch (type)
            {
                case "CONTAINER":
                    {
                        return ContentType.CONTAINER;
                    }
                case "DATA":
                    {
                        return ContentType.DATA;
                    }
                default:
                    {
                        return ContentType.UNDEF;
                    }
            }
        }
    }
    public class Frame
    {
        public String Msoh { get; set; }

        public String Rsoh { get; set; }

        public Container content { get; set; }

        public Frame()
        {

        }
    }
}
